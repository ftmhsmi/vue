
<script setup>
import { ref } from 'vue'

const count = ref(0)

function increase() {
  count.value++
}

function decrease() {
  count.value--
}

function reset() {
  count.value = 0
}
</script>

<template>
  <div class="container">
    <h1>شمارنده من</h1>

    <div class="counter">
      {{ count }}
    </div>

    <div class="buttons">
      <button @click="increase">افزایش +</button>
      <button @click="decrease">کاهش -</button>
      <button @click="reset">ریست</button>
    </div>
  </div>
</template>

<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: Tahoma, sans-serif;
  direction: rtl;
}

.container {
  text-align: center;
  margin: 100px auto;
  padding: 30px;
  max-width: 400px;
  background: #f1f5f9;
  border-radius: 20px;
}

h1 {
  color: #334155;
}

.counter {
  font-size: 60px;
  font-weight: bold;
  color: #2563eb;
  margin: 30px;
}

.buttons {
  display: flex;
  justify-content: center;
  gap: 10px;
  flex-wrap: wrap;
}

button {
  padding: 12px 18px;
  border: none;
  border-radius: 10px;
  background: #2563eb;
  color: white;
  cursor: pointer;
  font-size: 15px;
}

button:hover {
  background: #1d4ed8;
}
</style>
